import './Crearcuenta.css';
function Crearcuenta() {
    return (
        <main>
            <div className="crearcuenta">
                <div className="crearcuenta_contenedor">
                    <h2>Bienvenido al organizador de horarios CEDI</h2>
                    <p>Crea una nueva cuenta con tu correo institucional</p>
                    <form className="crearcuenta_form">
                        <input
                            type="email"
                            placeholder="   Correo electrónico"
                            required
                        />
                        <input
                            type="password"
                            placeholder="   Contraseña"
                            required
                        />
                        <input
                            type="text"
                            placeholder="   Nombre de usuario"
                            required
                        />

                        <button type="submit">
                            Crear cuenta
                        </button>
                    </form>
                </div>
            </div>
        </main>
    );
}

export default Crearcuenta;